<script>
    let menus = []; // To store fetched menus globally for filtering

    // Function to render menus based on the filtered data
    function renderMenus(filteredMenus) {
        const productContainer = document.getElementById('product-container');

        // Clear existing content
        productContainer.innerHTML = '';

        if (filteredMenus.length > 0) {
            // Loop through menus and create cards
            filteredMenus.forEach(menu => {
                const productCard = `
                    <div class="col-6 col-sm-4 col-md-3 mb-3">
                        <div class="card shadow-sm border-0 menu-item"
                             data-id="${menu.id}"
                             style="width: 150px; height: 220px; cursor: pointer;">
                            <div class="card-body text-center d-flex flex-column align-items-center justify-content-between">
                                <img src="${menu.itemImage || 'https://via.placeholder.com/100'}"
                                    class="img-fluid rounded mb-2" alt="${menu.itemName || 'Product'}"
                                    style="max-height: 100px;">
                                <h6 class="mt-2 fw-bold text-dark">${menu.itemName || 'Unknown'} (${menu.stock || 0})</h6>
                                <p class="text-muted small">Price: ₹${menu.price || 'N/A'}</p>
                            </div>
                        </div>
                    </div>`;
                productContainer.insertAdjacentHTML('beforeend', productCard);
            });

            // Add click event listener to menu items
            document.querySelectorAll('.menu-item').forEach(item => {
                item.addEventListener('click', function () {
                    const menuId = this.getAttribute('data-id');
                    const menuDetails = menus.find(menu => menu.id == menuId);
                    console.log(menuDetails);

                    // Send the clicked item's data to the server
                    sendData(menuDetails);
                });
            });
        } else {
            // Handle case when no menus match the search
            productContainer.innerHTML = `<p class="text-center text-muted">No menu items match your search.</p>`;
        }
    }

    // Fetch menu data from the API
    fetch('/get/menu/data')
        .then(response => response.json())
        .then(data => {
            if (data && data[0]?.data?.menus?.length > 0) {
                menus = data[0].data.menus; // Store the menus globally
                renderMenus(menus); // Render the initial menu list
            } else {
                const productContainer = document.getElementById('product-container');
                productContainer.innerHTML = `<p class="text-center text-muted">No menu items available.</p>`;
            }
        })
        .catch(error => {
            console.error('Error fetching menu data:', error);
            const productContainer = document.getElementById('product-container');
            productContainer.innerHTML = `<p class="text-center text-danger">Failed to load menu items.</p>`;
        });

    // Add event listener for the search input
    document.getElementById('search-input').addEventListener('input', function (event) {
        const searchTerm = event.target.value.toLowerCase();

        // Filter menus based on the search term
        const filteredMenus = menus.filter(menu =>
            menu.itemName.toLowerCase().includes(searchTerm)
        );

        // Re-render menus based on the filtered results
        renderMenus(filteredMenus);
    });

    // Function to send data to the server
    function sendData(data) {
        const formData = new FormData();
        formData.append('itemId', data.id);
        formData.append('itemName', data.itemName); // Corrected from 'data.name' to 'data.itemName'
        formData.append('price', data.price);

        fetch('/addData', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') // CSRF protection for Laravel
            },
            body: formData,
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(responseData => {
            console.log('Data successfully sent to the server:', responseData);
        })
        .catch(error => {
            console.error('Error sending data to the server:', error);
        });
    }
</script>
<?php /**PATH C:\Users\pc\Desktop\admin-dashboard\resources\views/components/till/itemList.blade.php ENDPATH**/ ?>