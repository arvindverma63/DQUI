


<script src="<?php echo e(asset('assets/js/transactions/transactions.js')); ?>"></script>
<?php /**PATH C:\Users\pc\Desktop\admin-dashboard\resources\views/components/transactionTable.blade.php ENDPATH**/ ?>