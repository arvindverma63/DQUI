<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td class="cell">#<?php echo e($supplier['id']); ?></td>
    <td class="cell"><?php echo e($supplier['supplierName']); ?></td>
    <td class="cell"><?php echo e($supplier['email']); ?></td>
    <td class="cell"><?php echo e($supplier['phoneNumber']); ?></td>
    <td class="cell"><?php echo e($supplier['rawItem']); ?></td>
    <td class="cell">
        <!-- Delete Supplier Action -->
        <a href="<?php echo e(route('delete.supplier', $supplier['id'])); ?>" onclick="return confirm('Are you sure you want to delete this supplier?')">
            <i class="fa-solid fa-trash" style="cursor: pointer;"></i>
        </a>

        <!-- Edit Supplier Modal Trigger -->
        <i class="fa-regular fa-pen-to-square" data-bs-toggle="modal" data-bs-target="#edit-supplier-<?php echo e($supplier['id']); ?>" style="cursor: pointer;"></i>
    </td>
</tr>

<!-- Modal for each supplier -->
<div class="modal fade" id="edit-supplier-<?php echo e($supplier['id']); ?>" tabindex="-1" aria-labelledby="edit-supplierLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="edit-supplierLabel">Edit Supplier - <?php echo e($supplier['supplierName']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Supplier Form -->
                <form id="supplierForm-<?php echo e($supplier['id']); ?>" method="POST" action="<?php echo e(route('update.supplier', $supplier['id'])); ?>">
                    <?php echo csrf_field(); ?> <!-- Add this if using Laravel Blade templates -->
                    <?php echo method_field('PUT'); ?> <!-- Ensure PUT method is used for updating -->

                    <div class="mb-3">
                        <label for="supplierName-<?php echo e($supplier['id']); ?>" class="form-label small">Supplier Name</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e($supplier['supplierName']); ?>" id="supplierName-<?php echo e($supplier['id']); ?>" name="supplierName" required placeholder="Enter supplier name">
                    </div>
                    <div class="mb-3">
                        <label for="email-<?php echo e($supplier['id']); ?>" class="form-label small">Email</label>
                        <input type="email" class="form-control form-control-sm" value="<?php echo e($supplier['email']); ?>" id="email-<?php echo e($supplier['id']); ?>" name="email" required placeholder="Enter supplier email">
                    </div>
                    <div class="mb-3">
                        <label for="phoneNumber-<?php echo e($supplier['id']); ?>" class="form-label small">Phone Number</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e($supplier['phoneNumber']); ?>" id="phoneNumber-<?php echo e($supplier['id']); ?>" name="phoneNumber" required placeholder="Enter phone number">
                    </div>
                    <div class="mb-3">
                        <label for="rawItem-<?php echo e($supplier['id']); ?>" class="form-label small">Raw Item</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e($supplier['rawItem']); ?>" id="rawItem-<?php echo e($supplier['id']); ?>" name="rawItem" required placeholder="Enter raw item">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary btn-sm" form="supplierForm-<?php echo e($supplier['id']); ?>">Save Supplier</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\pc\Documents\_test\resources\views/components/supplierTable.blade.php ENDPATH**/ ?>