<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td class="cell">#<?php echo e($stock['id']); ?></td>
    <td class="cell"><?php echo e($stock['itemName']); ?></td>
    <td class="cell"><?php echo e(number_format($stock['quantity'], 3)); ?></td>
    <td class="cell"><?php echo e($stock['unit']); ?></td>
    <td class="cell"><?php echo e($stock['supplier']['supplierName']); ?></td>
    <td class="cell">
        <!-- Delete Supplier Action -->
        <a href="<?php echo e(route('delete.stock', $stock['id'])); ?>" onclick="return confirm('Are you sure you want to delete this stock?')">
            <i class="fa-solid fa-trash" style="cursor: pointer;"></i>
        </a>

        <!-- Edit Stock Modal Trigger -->
        <i class="fa-regular fa-pen-to-square" data-bs-toggle="modal" data-bs-target="#edit-stock-<?php echo e($stock['id']); ?>" style="cursor: pointer;"></i>
    </td>
</tr>

<!-- Modal for each stock -->
<div class="modal fade" id="edit-stock-<?php echo e($stock['id']); ?>" tabindex="-1" aria-labelledby="edit-stockLabel-<?php echo e($stock['id']); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="edit-stockLabel-<?php echo e($stock['id']); ?>">Edit Stock - <?php echo e($stock['itemName']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Stock Form -->
                <form id="stockForm-<?php echo e($stock['id']); ?>" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="itemName-<?php echo e($stock['id']); ?>" class="form-label small">Item Name</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e($stock['itemName']); ?>" id="itemName-<?php echo e($stock['id']); ?>" name="itemName" required placeholder="Enter item name">
                    </div>
                    <div class="mb-3">
                        <label for="quantity-<?php echo e($stock['id']); ?>" class="form-label small">Quantity</label>
                        <input type="number" step="0.001" class="form-control form-control-sm" value="<?php echo e($stock['quantity']); ?>" id="quantity-<?php echo e($stock['id']); ?>" name="quantity" required placeholder="Enter quantity">
                    </div>
                    <div class="mb-3">
                        <label for="unit-<?php echo e($stock['id']); ?>" class="form-label small">Unit</label>
                        <input type="text" class="form-control form-control-sm" value="<?php echo e($stock['unit']); ?>" id="unit-<?php echo e($stock['id']); ?>" name="unit" required placeholder="Enter unit">
                    </div>
                    <div class="mb-3">
                        <label for="supplier-<?php echo e($stock['id']); ?>" class="form-label small">Supplier</label>
                        <select class="form-select" id="supplier-<?php echo e($stock['id']); ?>" name="supplierId">
                            <option value="<?php echo e($stock['supplier']['id']); ?>"><?php echo e($stock['supplier']['supplierName']); ?></option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary btn-sm" form="stockForm-<?php echo e($stock['id']); ?>">Save Stock</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\Hp\Documents\secret\admin-dashboard\resources\views/components/stockTable.blade.php ENDPATH**/ ?>