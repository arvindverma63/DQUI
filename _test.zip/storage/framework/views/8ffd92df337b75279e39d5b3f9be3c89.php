<?php if(empty($menuItems['data']['menus'])): ?>
    <p class="text-center">No menu items available.</p>
<?php else: ?>
    <!-- Table structure for DataTable -->
    <table id="menuTable" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Image</th>
                <th>Item Name</th>
                <th>Price</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $menuItems['data']['menus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img src="<?php echo e($menuItem['itemImage']); ?>" alt="<?php echo e($menuItem['itemName']); ?>" style="width: 50px; height: auto;">
                    </td>
                    <td><?php echo e($menuItem['itemName']); ?></td>
                    <td>$<?php echo e($menuItem['price']); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($menuItem['created_at'])->format('d-m-Y H:i')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($menuItem['updated_at'])->format('d-m-Y H:i')); ?></td>
                    <td>
                        <!-- Edit Menu Button -->
                        <a href="#" class="btn btn-sm btn-primary text-white" data-bs-toggle="modal" data-bs-target="#editMenuModal<?php echo e($menuItem['id']); ?>">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <!-- Delete Menu Form -->
                        <form action="<?php echo e(url('/menu/'.$menuItem['id'])); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger text-white" onclick="return confirm('Are you sure you want to delete this menu item?');">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                        </form>
                        <!-- Edit Stock Button -->
                        <a href="#" class="btn btn-sm btn-warning text-white" data-bs-toggle="modal" data-bs-target="#editStockModal<?php echo e($menuItem['id']); ?>">
                            <i class="fas fa-box"></i> Edit Stock
                        </a>
                    </td>
                </tr>

                <!-- Edit Menu Modal -->
                <div class="modal fade" id="editMenuModal<?php echo e($menuItem['id']); ?>" tabindex="-1" aria-labelledby="editMenuLabel<?php echo e($menuItem['id']); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editMenuLabel<?php echo e($menuItem['id']); ?>">Edit Menu Item: <?php echo e($menuItem['itemName']); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(url('/menu', $menuItem['id'])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-body">
                                    <!-- Item Name Field -->
                                    <div class="mb-3">
                                        <label for="itemName" class="form-label">Item Name</label>
                                        <input type="text" class="form-control" id="itemName" name="itemName" value="<?php echo e($menuItem['itemName']); ?>" required>
                                    </div>

                                    <!-- Category Dropdown -->
                                    <div class="mb-3">
                                        <label for="categoryId" class="form-label">Category</label>
                                        <select class="form-select" id="categorySelect<?php echo e($menuItem['id']); ?>" name="categoryId" required>
                                            <option value="">Select Category</option>
                                        </select>
                                    </div>

                                    <!-- Price Field -->
                                    <div class="mb-3">
                                        <label for="price" class="form-label">Price</label>
                                        <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo e($menuItem['price']); ?>" required>
                                    </div>


                                    <!-- Item Image Field -->
                                    <div class="mb-3">
                                        <label for="itemImage" class="form-label">Item Image</label>
                                        <input type="file" class="form-control" id="itemImage" name="itemImage" accept="image/jpeg, image/png, image/jpg, image/gif">
                                        <?php if($menuItem['itemImage']): ?>
                                            <div class="mt-2">
                                                <img src="<?php echo e($menuItem['itemImage']); ?>" alt="Current Image" style="width: 100px; height: auto;">
                                                <p class="text-muted">Current image</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Function to fetch and populate categories dynamically when the modal opens
                        const editMenuModal = document.getElementById('editMenuModal<?php echo e($menuItem['id']); ?>');
                        editMenuModal.addEventListener('show.bs.modal', function () {
                            const categorySelect = document.getElementById('categorySelect<?php echo e($menuItem['id']); ?>');

                            fetch('/getAllCategories')
                                .then(response => response.json())
                                .then(data => {
                                    const categories = data.category;
                                    categorySelect.innerHTML = '<option value="">Select a category</option>';
                                    categories.forEach(category => {
                                        const option = document.createElement('option');
                                        option.value = category.id;
                                        option.textContent = category.categoryName;

                                        // Pre-select the current category if it matches
                                        if (category.id == <?php echo e($menuItem['categoryId']); ?>) {
                                            option.selected = true;
                                        }

                                        categorySelect.appendChild(option);
                                    });
                                })
                                .catch(error => {
                                    console.error('Error loading categories:', error);
                                });
                        });
                    });
                </script>

  <!-- Edit Stock Modal -->
  <div class="modal fade" id="editStockModal<?php echo e($menuItem['id']); ?>" tabindex="-1" aria-labelledby="editStockLabel<?php echo e($menuItem['id']); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editStockLabel<?php echo e($menuItem['id']); ?>">Edit Stock for: <?php echo e($menuItem['itemName']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editStockForm<?php echo e($menuItem['id']); ?>" action="<?php echo e(url('updateMenuStock/' . $menuItem['id'])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Stock Items</label>
                        <div id="stockItemsContainer<?php echo e($menuItem['id']); ?>">
                            <!-- Existing stock items from database -->
                            <?php $__currentLoopData = $menuItem['stockItems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stockItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row g-2 mb-2 stock-item-row">
                                    <div class="col">
                                        <select class="form-select" name="stockItems[<?php echo e($index); ?>][stockId]" required>
                                            <option value="" disabled>Select Stock Item</option>
                                            <?php $__currentLoopData = $menuItems['data']['inventoryOptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($inventoryItem['id']); ?>" <?php echo e($stockItem['stockId'] == $inventoryItem['id'] ? 'selected' : ''); ?>>
                                                    <?php echo e($inventoryItem['itemName']); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <input type="number" step="0.001" class="form-control" name="stockItems[<?php echo e($index); ?>][quantity]" value="<?php echo e($stockItem['quantity']); ?>" placeholder="Quantity" required>
                                    </div>
                                    <div class="col-auto">
                                        <button type="button" class="btn btn-danger btn-sm remove-stock-item" onclick="removeStockItemRow(this)">&times;</button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="button" class="btn btn-primary btn-sm" onclick="addStockItemRow(<?php echo e($menuItem['id']); ?>)">Add Stock Item</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Stock</button>
                </div>
            </form>
        </div>
    </div>
</div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<!-- Template for Dynamic Stock Row - Place Outside of the Conditional Statements -->
<template id="stock-item-template">
    <div class="row g-2 mb-2 stock-item-row">
        <div class="col">
            <select class="form-select" required>
                <option value="" disabled selected>Select Stock Item</option>
                <?php $__currentLoopData = $menuItems['data']['inventoryOptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($inventoryItem['id']); ?>"><?php echo e($inventoryItem['itemName']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col">
            <input type="number" step="0.001" class="form-control" placeholder="Quantity" required>
        </div>
        <div class="col-auto">
            <button type="button" class="btn btn-danger btn-sm remove-stock-item" onclick="removeStockItemRow(this)">&times;</button>
        </div>
    </div>
</template>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize DataTable

        // Function to dynamically add stock item rows
        window.addStockItemRow = function(menuId) {
            const container = document.getElementById(`stockItemsContainer${menuId}`);
            const template = document.getElementById('stock-item-template').content.cloneNode(true);

            // Update `name` attributes dynamically based on the row count
            const index = container.querySelectorAll('.stock-item-row').length;
            template.querySelector('select').setAttribute('name', `stockItems[${index}][stockId]`);
            template.querySelector('input').setAttribute('name', `stockItems[${index}][quantity]`);

            container.appendChild(template);
        };

        // Function to remove a stock item row
        window.removeStockItemRow = function(button) {
            button.closest('.stock-item-row').remove();
        };
    });
</script>
<?php /**PATH /home/u972632477/domains/dicui.org/public_html/test/resources/views/components/menu-table.blade.php ENDPATH**/ ?>