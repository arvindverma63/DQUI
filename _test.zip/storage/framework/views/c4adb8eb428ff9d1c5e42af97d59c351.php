<div class="container-xl">
    <div class="row g-3 mb-4 align-items-center justify-content-between">
        <div class="col-auto">
            <h1 class="app-page-title mb-0">Orders</h1>
        </div>
        <div class="col-auto">
            <div class="page-utilities">
                <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                    <div class="col-auto">
                        <input type="text" id="search-orders" class="form-control search-orders" placeholder="Search" onkeyup="filterOrders()">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content" id="orders-table-tab-content">
        <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
            <div class="app-card app-card-orders-table shadow-sm mb-5">
                <div class="app-card-body">
                    <div class="table-responsive" style="padding: 20px;">
                        <table class="table app-table-hover mb-0 text-left" id="orders-table">
                            <thead>
                                <tr>
                                    <th class="cell">Order ID</th>
                                    <th class="cell">Items</th>
                                    <th class="cell">Customer</th>
                                    <th class="cell">Table Number</th>
                                    <th class="cell">Date</th>
                                    <th class="cell">Status</th>
                                    <th class="cell">Total</th>
                                    <th class="cell">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="orders-tbody">
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="cell">#<?php echo e($order['order_id']); ?></td>
                                    <td class="cell">
                                        <?php $__currentLoopData = $order['order_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div><?php echo e($item['item_name'] ?? 'Item Name N/A'); ?> (x<?php echo e($item['quantity']); ?>)</div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="cell"><?php echo e($order['user']['name'] ?? 'N/A'); ?></td>
                                    <td class="cell"><?php echo e($order['table_number']); ?></td>
                                    <td class="cell"><?php echo e(\Carbon\Carbon::parse($order['created_at'])->format('d M Y')); ?></td>
                                    <td class="cell">
                                        <span class="badge <?php echo e($order['status'] == 'processing' ? 'bg-warning' : ($order['status'] == 'complete' ? 'bg-success' : 'bg-danger')); ?>">
                                            <?php echo e(ucfirst($order['status'])); ?>

                                        </span>
                                    </td>
                                    <td class="cell">₹<?php echo e(number_format($order['total'], 2)); ?></td>
                                    <td class="cell">
                                        <!-- Button triggers offcanvas for order details -->
                                        <button class="btn-sm app-btn-secondary" data-bs-toggle="offcanvas" data-bs-target="#orderDetailsCanvas<?php echo e($order['order_id']); ?>">
                                            View
                                        </button>
                                    </td>
                                </tr>

                                <!-- Off-canvas for this order -->
                                <div class="offcanvas offcanvas-end" tabindex="-1" id="orderDetailsCanvas<?php echo e($order['order_id']); ?>" aria-labelledby="orderDetailsCanvasLabel<?php echo e($order['order_id']); ?>">
                                    <div class="offcanvas-header">
                                        <h5 class="offcanvas-title" id="orderDetailsCanvasLabel<?php echo e($order['order_id']); ?>">Order Details - #<?php echo e($order['order_id']); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                    </div>
                                    <div class="offcanvas-body">
                                        <p><strong>Customer:</strong> <?php echo e($order['user']['name'] ?? 'N/A'); ?></p>
                                        <p><strong>Table Number:</strong> <?php echo e($order['table_number']); ?></p>
                                        <p><strong>Status:</strong> <?php echo e(ucfirst($order['status'])); ?></p>
                                        <p><strong>Total:</strong> ₹<?php echo e(number_format($order['total'], 2)); ?></p>
                                        <p><strong>Items:</strong></p>
                                        <ul>
                                            <?php $__currentLoopData = $order['order_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($item['item_name'] ?? 'Item Name N/A'); ?> (x<?php echo e($item['quantity']); ?>)</li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="mt-3">
                                            <form action="<?php echo e(route('updateOrderStatus', $order['order_id'])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="complete">
                                                <button type="submit" class="btn btn-success text-white">Mark as Complete</button>
                                            </form>
                                            <form action="<?php echo e(route('updateOrderStatus', $order['order_id'])); ?>" method="POST" class="mt-2">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="reject">
                                                <button type="submit" class="btn btn-danger text-white">Reject Order</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Pagination -->
            <nav class="app-pagination" id="pagination">
                <!-- Pagination links will go here -->
            </nav>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\pc\Documents\_test\resources\views/components/order-table.blade.php ENDPATH**/ ?>