<!-- Modal -->
<div class="modal fade" id="uploadCategory" tabindex="-1" aria-labelledby="uploadCategoryLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg"> <!-- Use larger modal size for better layout -->
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title text-white" id="uploadCategoryLabel">Upload Category</h5>
                <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('addCategory')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Category Name input -->
                    <div class="mb-4">
                        <label class="form-label" for="categoryName">Category Name</label>
                        <input type="text" id="categoryName" class="form-control" name="categoryName" placeholder="Enter Category Name" required />
                    </div>

                    <!-- Image input -->
                    <div class="mb-4">
                        <label class="form-label" for="categoryImage">Upload Category Image</label>
                        <input type="file" id="categoryImage" class="form-control" name="categoryImage" required />
                    </div>

                    <!-- Submit button -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary text-white">Create Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert CDN -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- SweetAlert for Success and Error messages -->
<script>
    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: '<?php echo e(session('success')); ?>',
        });
    <?php endif; ?>

    <?php if(session('error')): ?>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<?php echo e(session('error')); ?>',
        });
    <?php endif; ?>

    <?php if($errors->any()): ?>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<?php echo e($errors->first()); ?>',
        });
    <?php endif; ?>
</script>
<?php /**PATH /home/u972632477/domains/dicui.org/public_html/test/resources/views/components/upload-category.blade.php ENDPATH**/ ?>