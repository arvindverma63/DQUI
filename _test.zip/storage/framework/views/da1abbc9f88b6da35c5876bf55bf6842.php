<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="app">
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.upload-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.tables.generateQr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="app-wrapper">
        <div class="app-content pt-3 p-md-3 p-lg-4">
            <div class="container">
                <center><h3>Generate Qr For Table <i class="fa-solid fa-qrcode"></i></h3></center>
                <div class="row g-3 mt-3">
                    <!-- Loop to dynamically generate cards -->
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-sm-6 col-md-4 col-lg-2">
                        <div class="dropdown">
                            <a href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="card text-center" style="width: 100px; height: 100px; margin: auto;">
                                    <div class="card-body d-flex align-items-center justify-content-center">
                                        <h5 class="card-title"><?php echo e($qr['tableNumber']); ?></h5>
                                    </div>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <li><a class="dropdown-item" href="/deleteQr/<?php echo e($qr['id']); ?>">Delete</a></li>
                                <li><a class="dropdown-item" href="<?php echo e($qr['qrCodeUrl']); ?>">Download</a></li>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Add New QR Card -->
                    <div class="col-6 col-sm-6 col-md-4 col-lg-2">
                        <div class="card text-center" style="width: 100px; height: 100px; margin: auto;cursor: pointer;" data-bs-toggle="modal" data-bs-target="#qrModal">
                            <div class="card-body d-flex align-items-center justify-content-center">
                                <h5 class="card-title">+</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--//container-->
        </div><!--//app-content-->
    </div><!--//app-wrapper-->
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/u972632477/domains/dicui.org/public_html/test/resources/views/qr.blade.php ENDPATH**/ ?>